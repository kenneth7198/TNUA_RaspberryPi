a = '200'
b = 100
c = int(a) / b
print(c)
