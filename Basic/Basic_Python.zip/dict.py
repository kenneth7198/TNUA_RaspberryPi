my_dict = {'a':1, 'b':2, 'c':3.14}
print(my_dict['b'])
