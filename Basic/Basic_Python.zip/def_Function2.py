def name (a='John', b='Kate'):
    if a == "May":
        print(a)
    else:
        print(b)

name("X")
