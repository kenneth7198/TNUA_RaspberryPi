from math import sqrt

print("Sqrt:",sqrt(2))
