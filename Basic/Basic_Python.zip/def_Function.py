def sumAll( x, y ):
    z = x + y
    return z

print(sumAll(4,8))
