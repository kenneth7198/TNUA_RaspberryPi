my_list=[5,20,45]
for i in range(0,3):
    print(my_list[i])
