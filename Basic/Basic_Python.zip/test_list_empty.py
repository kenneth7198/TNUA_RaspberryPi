my_list = []     
my_list2 = [10, 30, 0.001, ��abc��, 30, 40]
print(my_list2[4])
