my_list = []
my_list2 = [10, 30, 0.001, 'abc', 30, 40]
print(my_list2[4])

my_list.append(my_list2[2])
print(my_list[0])
