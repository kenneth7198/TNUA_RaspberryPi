a = "String"
b = 12.98
c ='A'
print("%s size is %d ,%c char is 14px" % (a,b,c))
