a = 'abc'
b = 'def'
c = a + b
print(c)
