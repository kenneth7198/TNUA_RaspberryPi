my_list = [1,2,3]
for i in my_list:
    print(i)
