a = 80
b = 50

if a < 100:
    if b > 30:
        print ("b>30")
    elif b < 30:
        print ("b<30")
    else:
        print ("b=30") 
elif a > 100 :
    print("a>100")
else:
    print("a=100")
