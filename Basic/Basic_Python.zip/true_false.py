a = 0
b = 1
c = a and b
print (c)
