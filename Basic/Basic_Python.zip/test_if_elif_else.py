a = True

if a == True:
    print ("a = true") 
elif a == False:
    print("a = false")
else:
    print("Why?")
