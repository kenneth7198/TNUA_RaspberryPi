my_list = [10,20,30]
i = 0
listTotal = len(my_list)
while i < listTotal:
    print("list:",i," = ",my_list[i])
    i += 1
else:
    print("end")

