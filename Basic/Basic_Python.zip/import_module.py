import math
import math as m

print("Sqrt:",math.sqrt(2))
print("Sqrt:",m.sqrt(2))
