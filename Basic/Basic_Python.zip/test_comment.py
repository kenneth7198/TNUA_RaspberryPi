# Test code
a = 100  #This is single line comment
c = 900
print(a)
if a < c :
    print("Yes")
    '''
    This is multiline comment.
    If you want to use multiline comment.
    Like this.

    '''
